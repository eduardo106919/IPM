const app = Vue.createApp({
  data() {
    return {
      todos: [
        'Learn a new course',
        'Read a book',
        'Go to the gym',
        'Go shopping'
      ]
    }
  },
  methods: {
   
  }
});
