<script>
export default {
  props: ['jogadorAJogar', 'vencedor']
}
</script>

<template>

</template>

<style scoped>
.button {
  border: 1px solid black;
  border-radius: 5px;
  text-align: center;
  padding: 10px;
  font-weight: 600;
}
</style>